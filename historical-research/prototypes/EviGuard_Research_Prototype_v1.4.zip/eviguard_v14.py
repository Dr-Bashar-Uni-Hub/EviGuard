"""v1.4: epoch-scoped evidence certification, intentionally conservative.
Not a network implementation; complete-snapshot roots must be authenticated externally.
"""
from dataclasses import dataclass
from eviguard_v13 import MerkleInventory

@dataclass(frozen=True)
class Attestation:
    epoch:int
    root:bytes

class EvidenceController:
    def __init__(self,a,b):
        self.a=a;self.b=b;self.epoch_a=0;self.epoch_b=0
        self.certs={};self.proof_checks=0;self.revocations=0
    def update(self,source,key,value):
        if source=='a':self.a.update(key,value);self.epoch_a+=1
        else:self.b.update(key,value);self.epoch_b+=1
    def attest(self):
        return (Attestation(self.epoch_a,self.a.root),Attestation(self.epoch_b,self.b.root))
    def certify(self,key):
        ta,tb=self.attest()
        va,vb=self.a.values[key],self.b.values[key]
        pa,pb=self.a.proof(key),self.b.proof(key)
        self.proof_checks+=2
        ok=(va==vb and MerkleInventory.verify(key,va,pa,ta.root) and MerkleInventory.verify(key,vb,pb,tb.root))
        if ok:self.certs[key]=(ta,tb,va)
        else:self.certs.pop(key,None)
        return ok
    def allowed(self,key):
        cert=self.certs.get(key)
        if not cert:return False
        ta,tb,value=cert
        return (ta,tb)==self.attest() and value==1

class IncrementalBaseline(EvidenceController):
    """Strong fair baseline: same authenticated epochs, proofs and safety rule."""
    pass
