import csv,random,json
from eviguard_v13 import MerkleInventory
from eviguard_v14 import EvidenceController,IncrementalBaseline

def trial(seed,n=128,steps=200):
    r=random.Random(seed);base={f'k{i}':1 for i in range(n)}
    controllers=[EvidenceController(MerkleInventory(base),MerkleInventory(base)),IncrementalBaseline(MerkleInventory(base),MerkleInventory(base))]
    unsafe=[0,0];denied=[0,0];checks=[0,0];stale=0
    for _ in range(steps):
        key=f'k{r.randrange(n)}';action=r.choice(['a','b','both','cert','read','read'])
        if action in ('a','b','both'):
            val=r.randrange(2)
            for c in controllers:
                if action in ('a','both'):c.update('a',key,val)
                if action in ('b','both'):c.update('b',key,val)
        elif action=='cert':
            for c in controllers:c.certify(key)
        else:
            for i,c in enumerate(controllers):
                accept=c.allowed(key)
                safe=(c.a.values[key]==c.b.values[key]==1)
                unsafe[i]+=int(accept and not safe)
                denied[i]+=int(not accept and safe)
            stale+=int(key in controllers[0].certs and not controllers[0].allowed(key))
    assert all(c.attest()==controllers[0].attest() for c in controllers)
    assert all(c.certs==controllers[0].certs for c in controllers)
    return dict(seed=seed,n=n,steps=steps,unsafe_eviguard=unsafe[0],unsafe_baseline=unsafe[1],denied_eviguard=denied[0],denied_baseline=denied[1],proof_checks_eviguard=controllers[0].proof_checks,proof_checks_baseline=controllers[1].proof_checks,stale_certificate_reads=stale)
if __name__=='__main__':
    rows=[trial(s) for s in range(1000)]
    with open('results_v14_raw.csv','w',newline='') as f:
        w=csv.DictWriter(f,rows[0].keys());w.writeheader();w.writerows(rows)
    summary={k:sum(row[k] for row in rows) for k in rows[0] if k!='seed'}
    with open('results_v14_summary.json','w') as f:json.dump(summary,f,indent=2)
    print(json.dumps(summary,indent=2))
