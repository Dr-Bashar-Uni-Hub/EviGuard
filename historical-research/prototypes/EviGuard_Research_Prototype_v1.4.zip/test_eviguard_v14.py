import unittest
from eviguard_v13 import MerkleInventory
from eviguard_v14 import EvidenceController
from run_v14 import trial
class TestV14(unittest.TestCase):
    def make(self):return EvidenceController(MerkleInventory({'a':1,'b':1}),MerkleInventory({'a':1,'b':1}))
    def test_certify(self):
        c=self.make();self.assertTrue(c.certify('a'));self.assertTrue(c.allowed('a'))
    def test_single_source_change_invalidates_all(self):
        c=self.make();c.certify('a');c.update('b','b',0);self.assertFalse(c.allowed('a'))
    def test_mismatch_rejected(self):
        c=self.make();c.update('a','a',0);self.assertFalse(c.certify('a'))
    def test_recovers_after_reconciliation(self):
        c=self.make();c.update('a','a',0);c.update('b','a',0);self.assertTrue(c.certify('a'));self.assertFalse(c.allowed('a'))
    def test_no_oracle_claim(self):
        c=self.make();c.certify('a');c.update('a','b',0);self.assertFalse(c.allowed('a'))
    def test_fair_baseline(self):
        for s in range(30):
            d=trial(s);self.assertEqual(d['unsafe_eviguard'],d['unsafe_baseline']);self.assertEqual(d['denied_eviguard'],d['denied_baseline'])
if __name__=='__main__':unittest.main()
