# EviGuard v1.4 — Epoch-scoped evidence certification

## Design
Two independently updated Merkle inventories. A certificate is issued only when both sources return the same value and each inclusion proof verifies against its current root. A certificate is valid only while **both** root/epoch pairs remain unchanged. This is a deliberately conservative all-record invalidation rule; the Merkle roots are not externally signed, and inventory completeness is assumed. It is not a deployed network controller.

## Measured experiment
1,000 deterministic synthetic seeds, 128 records, 200 event steps per seed. 200,000 steps total. The event generator mixes single-source updates, both-source updates, certification, and authorization checks. The fair incremental baseline receives exactly the same events, proof budget, and trust assumptions. See `results_v14_raw.csv` and `results_v14_summary.json`.

## Results
- Unsafe accepts: 0 for both policies, under the modeled condition that authorization is safe only when both source values equal 1.
- Legitimate denials: 55,923 for each policy (counts of sampled authorization checks, not rate).
- Inclusion proof verifications: 66,572 for each policy.
- Reads of stale certificates: 7,342, denied by epoch/root invalidation.
- Six v1.4 tests passed.

## Critical caveats
- **No advantage over the strong incremental baseline.** Same safety, disruption, and proof cost.
- Every source update invalidates *all* previously certified records, causing substantial disruption. This is not an efficient selective-certification protocol.
- The reference safety oracle is a synthetic two-source agreement predicate, not real DHCP/DAI/IPSG semantics. Agreement of two incorrect inventories is undetectable.
- A cryptographic root without independently authenticated source provenance cannot establish trust. No signed deltas, append-only logs, source compromise, replayed signed checkpoints, crash consistency, or distributed switch enforcement are implemented.
- Safety depends on roots/epochs being observed atomically at the authorization point. In an asynchronous distributed deployment, this must be implemented with an explicit fence or version-pinned enforcement.

## Research implication
A safe selective protocol must invalidate only certificates touched by provably complete delta ranges. That requires authenticated append-only event provenance, non-membership and deletion proofs, gap detection, and conservative protection on unresolved ranges. Existing authenticated data structures and incremental verification are strong prior-art baselines. Novelty is not established.

## Reproduce
`python -m unittest -q test_eviguard_v14 && python run_v14.py`
