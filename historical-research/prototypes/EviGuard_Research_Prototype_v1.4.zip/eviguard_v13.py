"""EviGuard v1.3 experimental authenticated deltas and two-source reconciliation.
Toy trust model: two independent complete sources are required for certification;
cryptographic hashes detect tampering, NOT common-mode omissions. No signatures.
"""
import hashlib,json,random

def H(x):return hashlib.sha256(x).digest()
def enc(x):return json.dumps(x,sort_keys=True,separators=(',',':')).encode()
def leaf(k,v):return H(b'L'+enc([k,v]))
def parent(a,b):return H(b'I'+a+b)

class MerkleInventory:
    def __init__(self,records):
        self.keys=sorted(records);self.index={k:i for i,k in enumerate(self.keys)}
        self.values=dict(records);self.size=1
        while self.size<len(self.keys):self.size*=2
        self.nodes=[b'']*(2*self.size);self.hash_ops=0
        for i,k in enumerate(self.keys):self.nodes[self.size+i]=self._leaf(k,records[k])
        for i in range(len(self.keys),self.size):self.nodes[self.size+i]=self._leaf('',None)
        for i in range(self.size-1,0,-1):self.nodes[i]=self._parent(self.nodes[2*i],self.nodes[2*i+1])
    def _leaf(self,k,v):self.hash_ops+=1;return leaf(k,v)
    def _parent(self,a,b):self.hash_ops+=1;return parent(a,b)
    @property
    def root(self):return self.nodes[1]
    def proof(self,key):
        i=self.size+self.index[key];out=[]
        while i>1:out.append((i%2==1,self.nodes[i^1]));i//=2
        return out
    @staticmethod
    def verify(key,value,proof,root):
        d=leaf(key,value)
        for is_right,sibling in proof:d=parent(sibling,d) if is_right else parent(d,sibling)
        return d==root
    def update(self,key,value):
        i=self.size+self.index[key];self.values[key]=value;self.nodes[i]=self._leaf(key,value)
        while i>1:
            i//=2;self.nodes[i]=self._parent(self.nodes[2*i],self.nodes[2*i+1])

class Reconciler:
    def __init__(self,a,b):
        assert set(a.values)==set(b.values)
        self.a=a;self.b=b;self.epoch=0;self.quarantine=set()
    def reconcile(self,keys):
        self.epoch+=1
        for k in keys:
            pa=self.a.proof(k);pb=self.b.proof(k)
            if not MerkleInventory.verify(k,self.a.values[k],pa,self.a.root):raise ValueError('source A proof')
            if not MerkleInventory.verify(k,self.b.values[k],pb,self.b.root):raise ValueError('source B proof')
            if self.a.values[k]!=self.b.values[k]:self.quarantine.add(k)
            else:self.quarantine.discard(k)
        return not bool(self.quarantine)
    def allowed(self,key):return key not in self.quarantine

def run_trial(n,updates,seed,disagreement_rate=0):
    rng=random.Random(seed);base={f'k{i:05}':0 for i in range(n)}
    a=MerkleInventory(base);b=MerkleInventory(base);rec=Reconciler(a,b)
    incremental_hashes=0;full_hashes=0;disagreements=0
    for _ in range(updates):
        k=rng.choice(a.keys);v=a.values[k]+1
        start=a.hash_ops+b.hash_ops
        a.update(k,v)
        if rng.random()>=disagreement_rate:b.update(k,v)
        rec.reconcile([k]);disagreements+=int(not rec.allowed(k))
        incremental_hashes+=a.hash_ops+b.hash_ops-start
        # fair full-rebuild baseline, identical two source values and same disagreement handling
        aa=MerkleInventory(a.values);bb=MerkleInventory(b.values)
        full_hashes+=aa.hash_ops+bb.hash_ops
        assert aa.root==a.root and bb.root==b.root
        assert rec.allowed(k)==(a.values[k]==b.values[k])
    return dict(n=n,updates=updates,seed=seed,disagreement_rate=disagreement_rate,incremental_hashes=incremental_hashes,full_rebuild_hashes=full_hashes,disagreement_events=disagreements,common_mode_omission_detected=False)
